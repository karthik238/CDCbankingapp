<%-- 
    Document   : student
    Created on : Jan 3, 2026, 4:34:06 PM
    Author     : sathya.malli
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*,model.Student" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Add Student</h2>
        <form action="student" method="post">
        Name: <input name="name"><br>
        Email: <input name="email"><br>
        <input type="submit" value="Save">
        </form>

        <h2>Student List</h2>
        <table border="1">
        <tr><th>ID</th><th>Name</th><th>Email</th></tr>

        <%
        List<Student> list = (List<Student>)request.getAttribute("list");
        for(Student s : list){
        %>
        <tr>
        <td><%=s.getId()%></td>
        <td><%=s.getName()%></td>
        <td><%=s.getEmail()%></td>
        </tr>
        <% } %>

        </table>
    </body>
</html>
