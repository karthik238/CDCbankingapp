/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Student;
import model.StudentDAO;

/**
 *
 * @author sathya.malli
 */
@WebServlet(name = "StudentServlet", urlPatterns = {"/StudentServlet"})
public class StudentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse res)
            throws IOException, ServletException {
        try {
            StudentDAO dao = new StudentDAO();
            req.setAttribute("list", dao.getAll());
            req.getRequestDispatcher("student.jsp")
               .forward(req,res);
        } catch(Exception e) {
        }
    }

    @Override
    protected void doPost(HttpServletRequest req,
                          HttpServletResponse res)
            throws IOException {
        try {
            Student s = new Student();
            s.setName(req.getParameter("name"));
            s.setEmail(req.getParameter("email"));
            new StudentDAO().insert(s);
            res.sendRedirect("student");
        } catch(Exception e) {
        }
    }
}
