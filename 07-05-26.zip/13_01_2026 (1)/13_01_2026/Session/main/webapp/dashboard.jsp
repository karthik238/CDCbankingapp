<%-- 
    Document   : dashboard
    Created on : Jan 6, 2026, 10:22:32 PM
    Author     : sathya.malli
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Welcome ${username}</h2>
        <a href="logout">Logout</a>
    </body>
</html>
