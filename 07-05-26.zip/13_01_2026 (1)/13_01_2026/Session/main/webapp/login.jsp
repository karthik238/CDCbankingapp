<%-- 
    Document   : login
    Created on : Jan 6, 2026, 10:14:23 PM
    Author     : sathya.malli
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="login" method="post">
            Username: <input type="text" name="username" required /><br/>
            Password: <input type="password" name="password" required /><br/>
            <input type="submit" value="Login" />
        </form>
    </body>
</html>
